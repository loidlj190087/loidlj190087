/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package packageOne;

/**
 *
 * @author loidl
 */
public interface PrimeSieve {
    //Überprüft ob p eine Primzahl ist oder nicht.
    public boolean isPrime(int p);
    //Gibt alle Primzahlen bis zur Obergrenze auf der Konsole aus.
    public void printPrimes();
}
